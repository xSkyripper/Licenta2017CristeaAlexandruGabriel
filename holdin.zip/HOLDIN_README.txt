===== Guide ====
Follow Cordova guide on how to set up the dev enviroment !
https://cordova.apache.org/docs/en/latest/guide/platforms/android/index.html#requirements-and-support

Requirments (these were used for the app's dev but newer versions may work aswell):

    Android SDK, API Level 19 - 25 (Android 4.4 - 7.1.1)
    Android SDK Platform-Tools 25.0.4
    Android SDK Tools 26.0.1
    npm 4.6.1-1
    node 7.10.0-2
    cordova 6.5.0 (if you use 7.0.1, please install gradle 4.0 and add it to path)

export ANDROID_HOME, JAVA_HOME (relative, based on each Linux OS paths / versions)
attach to PATH: /Android/Sdk/platform-tools
attach to PATH: /Android/Sdk/tools
attach to PATH: gradle/bin

===== Links =====
HOLDIN:              https://github.com/xSkyripper/holdin
Cordova-IPFS-Plugin: https://github.com/xSkyripper/cordova-plugin-ipfs
JS-IPFS-API:         https://github.com/ipfs/js-ipfs-api
Framework7-Vue:      https://github.com/nolimits4web/Framework7-Vue


===== Steps ======
1.  $ git clone https://github.com/xSkyripper/holdin
    $ cd holdin
    $ mkdir www     # if it's not present

2.  $ git clone https://github.com/ipfs/js-ipfs-api
    $ npm install
    -> modify 'const isNode = require('detect-node')'
       to 'const isNode = true'
       in 'js-ipfs-api/src/pubsub.js' (among first lines)
       and SAVE
    $ npm link
    $ npm link ipfs-api    # in holdin dir !!

3.  $ git clone https://github.com/nolimits4web/Framework7-Vue
    $ npm install
    $ npm run dist
    $ npm link '<path/to/dir>/Framework7-vue'    # in holdin dir

4.  $ cordova prepare

5.  $ cordova run android
    OR
    $ cordova build android
